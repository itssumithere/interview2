import React from 'react'

function Footer() {
  return (
    <div className='fixed bottom-0 bg-slate-900 text-white w-full h-16'>
        Right are with Sumit
    </div>
  )
}

export default Footer
